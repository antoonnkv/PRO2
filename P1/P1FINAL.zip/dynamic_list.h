/*
 * TITLE: PROGRAMMING II LABS
 * SUBTITLE: Practical 1
 * AUTHOR 1: Antón Vilas Pazos  LOGIN 1: anton.vilas.pazos@udc.es
 * AUTHOR 2: Alejandro Mosquera Cardeso LOGIN 2: alejandro.mosquera.cardeso@udc.es
 * GROUP: 4.2
 * DATE: 02 / 03 / 24
 */

#ifndef DYNAMIC_LIST_H
#define DYNAMIC_LIST_H

#include "types.h"
#include "stdlib.h"
#define LNULL NULL

typedef struct tNode *tPosL;

struct tNode{
    tItemL data;
    tPosL next;
};
typedef tPosL tList;

void createEmptyList(tList *L);
bool isEmptyList(tList L);
tPosL first(tList L);
tPosL last(tList L);
tPosL next(tPosL pos, tList L);
tPosL previous(tPosL pos, tList L);
bool insertItem(tItemL item, tPosL pos, tList *L);
void deleteAtPosition(tPosL pos, tList *L);
tItemL getItem(tPosL pos, tList L);
void updateItem(tItemL item, tPosL pos, tList *L);
tPosL findItem(tUserName name, tList L);

#endif
